# QuantumSocket

QuantumSocket is Socket for gestonnary of Multiplaying
